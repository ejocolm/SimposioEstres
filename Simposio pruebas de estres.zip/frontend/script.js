document.addEventListener('DOMContentLoaded', loadAlumnos);
document.getElementById("formAlumno").addEventListener("submit", async (e) => {
    e.preventDefault();
    const alumno = {
        nombre: document.getElementById("nombre").value,
        primerApellido: document.getElementById("primerApellido").value,
        segundoApellido: document.getElementById("segundoApellido").value,
        vigente: document.getElementById("vigente").checked
    };

    const response = await fetch("http://localhost:3000/api/alumnos", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(alumno)
    });
    if (response.ok) {
        alert("Alumno registrado!");
        loadAlumnos();
    }
});

async function loadAlumnos() {
    const response = await fetch('http://localhost:3000/api/alumnos');
    const alumnos = await response.json();
    renderTable(alumnos);
}

async function searchAlumnos() {
    const nombre = document.getElementById('searchInput').value;
    const response = await fetch(`http://localhost:3000/api/alumnos/search?nombre=${nombre}`);
    const alumnos = await response.json();
    renderTable(alumnos);
}

function renderTable(alumnos) {
    const tbody = document.querySelector('#alumnosTable tbody');
    tbody.innerHTML = '';
    alumnos.forEach(alumno => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${alumno.id}</td>
            <td>${alumno.nombre}</td>
            <td>${alumno.primerApellido}</td>
            <td>${alumno.segundoApellido || ''}</td>
            <td>${alumno.vigente ? 'Sí' : 'No'}</td>
        `;
        tbody.appendChild(row);
    });
}