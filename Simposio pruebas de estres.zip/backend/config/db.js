const sql = require('mssql');

const config = {
    user: 'sa',
    password: 'Lab2med',
    server: 'GTLTEC04', 
    database: 'Simposio2025',
    options: {
        encrypt: false,
        trustServerCertificate: true,
        enableArithAbort: true,
        instanceName: 'SQLEXPRESS' 
    },   
};

const pool = new sql.ConnectionPool(config);
pool.connect();
module.exports = pool;