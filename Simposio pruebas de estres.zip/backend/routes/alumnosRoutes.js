const express = require('express');
const router = express.Router();
const alumnosController = require('../controllers/alumnosController');

router.post('/', alumnosController.createAlumno);
router.get('/', alumnosController.getAllAlumnos);
router.get('/search', alumnosController.searchAlumnos);

module.exports = router;