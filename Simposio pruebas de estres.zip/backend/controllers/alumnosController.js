const sql = require('mssql');
const pool = require('../config/db');

exports.createAlumno = async (req, res) => {
    try {
        const { nombre, primerApellido, segundoApellido, vigente } = req.body;
        const request = pool.request();
        await request
            .input('nombre', sql.VarChar, nombre)
            .input('primerApellido', sql.VarChar, primerApellido)
            .input('segundoApellido', sql.VarChar, segundoApellido)
            .input('vigente', sql.Bit, vigente)
            .query(`
                INSERT INTO _alumnos (nombre, primerApellido, segundoApellido, vigente)
                VALUES (@nombre, @primerApellido, @segundoApellido, @vigente)
            `);
        res.status(201).json({ message: 'Alumno creado' });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};

exports.getAllAlumnos = async (req, res) => {
    try {
        const request = pool.request();
        const result = await request.query('SELECT * FROM _alumnos');
        res.json(result.recordset);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};

exports.searchAlumnos = async (req, res) => {
    try {
        const { nombre } = req.query;
        const request = pool.request();
        const result = await request
            .input('nombre', sql.VarChar, `%${nombre}%`)
            .query('SELECT * FROM _alumnos WHERE nombre LIKE @nombre');
        res.json(result.recordset);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};